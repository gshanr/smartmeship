var structdn__gpio__ioctl__notif__enable__t =
[
    [ "fEnable", "structdn__gpio__ioctl__notif__enable__t.html#a6322ceef8013c432636796e42d99d3b9", null ],
    [ "activeLevel", "structdn__gpio__ioctl__notif__enable__t.html#a32864135e27b5a7b8de4b19c3e49f27b", null ],
    [ "notifChannelId", "structdn__gpio__ioctl__notif__enable__t.html#a042388d39ec76f4db8cd3c1336dbed94", null ]
];