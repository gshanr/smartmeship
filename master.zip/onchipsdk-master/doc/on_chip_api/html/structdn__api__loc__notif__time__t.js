var structdn__api__loc__notif__time__t =
[
    [ "upTime", "structdn__api__loc__notif__time__t.html#acc0995851723a415a458a645ce8f8cd6", null ],
    [ "utcTime", "structdn__api__loc__notif__time__t.html#acd254388f0d24657fe9923631c3e1910", null ],
    [ "asn", "structdn__api__loc__notif__time__t.html#ae70ca2c09de421fceb9e482aa2fe5c50", null ],
    [ "offset", "structdn__api__loc__notif__time__t.html#a9851db06897094b16c2046f53139fda5", null ],
    [ "asnSubOffset", "structdn__api__loc__notif__time__t.html#a77d55e5d17be1279ecf5686db34afcc8", null ]
];