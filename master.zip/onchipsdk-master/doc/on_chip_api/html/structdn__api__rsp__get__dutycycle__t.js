var structdn__api__rsp__get__dutycycle__t =
[
    [ "rc", "structdn__api__rsp__get__dutycycle__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__dutycycle__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "dutyCycle", "structdn__api__rsp__get__dutycycle__t.html#a58fb21fa11ffbc9af0586c5f155e0ffa", null ]
];