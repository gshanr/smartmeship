var structdn__api__cmd__hdr__t =
[
    [ "cmdId", "structdn__api__cmd__hdr__t.html#a0d7fe903f3d1bb4828ccdabf7247d283", null ],
    [ "len", "structdn__api__cmd__hdr__t.html#a9c76acecd4a9805f0a5b851d966bdbfa", null ]
];