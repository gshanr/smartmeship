var structdn__cli__notif_msg__t =
[
    [ "type", "structdn__cli__notif_msg__t.html#a7aead736a07eaf25623ad7bfa1f0ee2d", null ],
    [ "cmdId", "structdn__cli__notif_msg__t.html#acce54cce1fefd5461438cf29edb494d8", null ],
    [ "offset", "structdn__cli__notif_msg__t.html#a7a229a4786deeddd59c6091247a8c8a6", null ],
    [ "data", "structdn__cli__notif_msg__t.html#a27836212d7e9f847d26a1fc6e238c40b", null ]
];