var searchData=
[
  ['value',['value',['../structdn__api__loc__svcrequest__t.html#a84b41d9d81f3abeb38118988f6211f0f',1,'dn_api_loc_svcrequest_t::value()'],['../structdn__api__loc__rsp__get__service__t.html#a84b41d9d81f3abeb38118988f6211f0f',1,'dn_api_loc_rsp_get_service_t::value()']]],
  ['vendorid',['vendorId',['../structdn__exec__par__hdr__t.html#a8865044b0e3ecffef887ad9fa19d56c9',1,'dn_exec_par_hdr_t::vendorId()'],['../structdn__api__set__appinfo__t.html#a8865044b0e3ecffef887ad9fa19d56c9',1,'dn_api_set_appinfo_t::vendorId()'],['../structdn__api__rsp__get__appinfo__t.html#a8865044b0e3ecffef887ad9fa19d56c9',1,'dn_api_rsp_get_appinfo_t::vendorId()']]],
  ['version',['version',['../structdn__exec__par__hdr__t.html#ab91f5a76a5e06ee7ea72f5df7c9068c1',1,'dn_exec_par_hdr_t']]],
  ['vgagain',['vgaGain',['../structdn__adc__drv__open__args__t.html#a7c3a35611c921762630949021589276f',1,'dn_adc_drv_open_args_t::vgaGain()'],['../structdn__adc__drv__ioctl__vga__t.html#a2f5a00196e43bb13ce2bfdfade28e781',1,'dn_adc_drv_ioctl_vga_t::vgaGain()']]]
];
