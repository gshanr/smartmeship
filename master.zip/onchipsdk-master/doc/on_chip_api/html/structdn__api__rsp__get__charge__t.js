var structdn__api__rsp__get__charge__t =
[
    [ "rc", "structdn__api__rsp__get__charge__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__charge__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "qTotal", "structdn__api__rsp__get__charge__t.html#a48ebb73d49f5efa6973a9af67bc8df46", null ],
    [ "upTime", "structdn__api__rsp__get__charge__t.html#acc0995851723a415a458a645ce8f8cd6", null ],
    [ "tempInt", "structdn__api__rsp__get__charge__t.html#acb8026363ff79375fdf9f96dc947cfa5", null ],
    [ "tempFrac", "structdn__api__rsp__get__charge__t.html#a936be957218a7fe3314bbe6be7a7d476", null ]
];