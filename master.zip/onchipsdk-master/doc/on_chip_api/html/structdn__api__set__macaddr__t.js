var structdn__api__set__macaddr__t =
[
    [ "paramId", "structdn__api__set__macaddr__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "macAddr", "structdn__api__set__macaddr__t.html#a6ff67cdb490916e93b37e8eb36aed4c8", null ]
];