var structdn__cli__open__args__t =
[
    [ "port", "structdn__cli__open__args__t.html#af8fb0f45ee0195c7422a49e6a8d72369", null ],
    [ "baudRate", "structdn__cli__open__args__t.html#a26bf015dc9c2a68aa1a2ccca24d543a0", null ]
];