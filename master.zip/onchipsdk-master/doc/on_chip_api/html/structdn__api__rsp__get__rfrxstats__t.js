var structdn__api__rsp__get__rfrxstats__t =
[
    [ "rc", "structdn__api__rsp__get__rfrxstats__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__rfrxstats__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "rxOkCnt", "structdn__api__rsp__get__rfrxstats__t.html#ac34f1f6ffc4f905860d14eb08f7d4851", null ],
    [ "rxFailCnt", "structdn__api__rsp__get__rfrxstats__t.html#a96e36217f138117ca1b569526a933f39", null ]
];