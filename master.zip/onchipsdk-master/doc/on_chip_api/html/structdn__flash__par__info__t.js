var structdn__flash__par__info__t =
[
    [ "parId", "structdn__flash__par__info__t.html#a9771696d72d67573493f4b17990af017", null ],
    [ "par", "structdn__flash__par__info__t.html#aec9bedb1b74541cb667233606eceece0", null ],
    [ "size", "structdn__flash__par__info__t.html#a77315a3809372af005131d14fdcafbba", null ],
    [ "pageSize", "structdn__flash__par__info__t.html#a8f8773c4f426baf839803d4feb0eb8ba", null ],
    [ "addr", "structdn__flash__par__info__t.html#a77ce5b2aff7048aaac1a3f4dbd294c9f", null ],
    [ "flags", "structdn__flash__par__info__t.html#ab6b306ef981f5e21bb41ea2c2dbe8cd9", null ]
];