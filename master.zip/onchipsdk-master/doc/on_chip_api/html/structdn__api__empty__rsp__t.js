var structdn__api__empty__rsp__t =
[
    [ "hdr", "structdn__api__empty__rsp__t.html#adf3722e76f24254efb1d038b738c4b1b", null ],
    [ "rc", "structdn__api__empty__rsp__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ]
];