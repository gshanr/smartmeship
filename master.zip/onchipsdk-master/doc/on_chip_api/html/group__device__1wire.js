var group__device__1wire =
[
    [ "dn_ow_open_args_t", "structdn__ow__open__args__t.html", [
      [ "maxTransactionLength", "structdn__ow__open__args__t.html#a1835ad505054c6045d1e0100973b6bb7", null ]
    ] ],
    [ "dn_ow_ioctl_detect_t", "structdn__ow__ioctl__detect__t.html", [
      [ "slavePresent", "structdn__ow__ioctl__detect__t.html#a7b8c4ca61076711836adc7319f987be5", null ]
    ] ],
    [ "dn_ow_ioctl_readbit_t", "structdn__ow__ioctl__readbit__t.html", [
      [ "readData", "structdn__ow__ioctl__readbit__t.html#ae40cf316e7944950598823ec9c117140", null ]
    ] ],
    [ "dn_ow_ioctl_writebit_t", "structdn__ow__ioctl__writebit__t.html", [
      [ "writeData", "structdn__ow__ioctl__writebit__t.html#ae61bd828090a5da6bd3342318148d437", null ]
    ] ],
    [ "DN_IOCTL_1WIRE_DETECT", "group__device__1wire.html#ga1edd98fe7bbc7d42e0a9e9ed165f6adb", null ],
    [ "DN_IOCTL_1WIRE_READBIT", "group__device__1wire.html#gad2f258b3e47e25ca46109c2b69b26833", null ],
    [ "DN_IOCTL_1WIRE_WRITEBIT", "group__device__1wire.html#gab10db2059cf483aa33f6d95f6e0b212f", null ]
];