var searchData=
[
  ['qtotal',['qTotal',['../structdn__api__rsp__get__charge__t.html#a48ebb73d49f5efa6973a9af67bc8df46',1,'dn_api_rsp_get_charge_t']]]
];
