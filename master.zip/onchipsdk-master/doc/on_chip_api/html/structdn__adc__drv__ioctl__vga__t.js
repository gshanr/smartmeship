var structdn__adc__drv__ioctl__vga__t =
[
    [ "vgaGain", "structdn__adc__drv__ioctl__vga__t.html#a2f5a00196e43bb13ce2bfdfade28e781", null ],
    [ "fBypassVga", "structdn__adc__drv__ioctl__vga__t.html#a92808f572ea7044d7ed4d33769880ddc", null ]
];