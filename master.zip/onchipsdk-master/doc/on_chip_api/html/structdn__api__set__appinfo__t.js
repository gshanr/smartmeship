var structdn__api__set__appinfo__t =
[
    [ "paramId", "structdn__api__set__appinfo__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "vendorId", "structdn__api__set__appinfo__t.html#a8865044b0e3ecffef887ad9fa19d56c9", null ],
    [ "appId", "structdn__api__set__appinfo__t.html#a50e438b64fea06036e55a8d3c4fb4583", null ],
    [ "appVer", "structdn__api__set__appinfo__t.html#ad8457c43ada8ec30a459735256c94014", null ]
];