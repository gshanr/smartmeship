var group__dn__time =
[
    [ "dn_time_utc_t", "structdn__time__utc__t.html", [
      [ "sec", "structdn__time__utc__t.html#ab11daf950596cb87689e3e614d05e7b2", null ],
      [ "usec", "structdn__time__utc__t.html#afd720181035c76f85c18c24b694c3cc3", null ]
    ] ],
    [ "dn_time_asn_t", "structdn__time__asn__t.html", [
      [ "asn", "structdn__time__asn__t.html#aed42fe3bc7b2e021c5fb33389175e32c", null ],
      [ "offset", "structdn__time__asn__t.html#a9851db06897094b16c2046f53139fda5", null ]
    ] ],
    [ "USEC_PER_SEC", "group__dn__time.html#ga6a69d6cbdab5f24c2e66959293f210c1", null ],
    [ "TIMER_TICKS_PER_SEC", "group__dn__time.html#ga3790164b4b6781f5988faf9c05d8eb1d", null ],
    [ "DN_IOCTL_TIME_ENABLE_PPS", "group__dn__time.html#gaa5e8c41b53ea7acfce85570f6ff54985", null ],
    [ "dn_getNetworkTime", "group__dn__time.html#ga0365b444b078c5693f4fe0f541ed0854", null ],
    [ "dn_getSystemTime", "group__dn__time.html#gae5f291f2b7582294de66917cc47a05cd", null ],
    [ "dn_asnToUtc", "group__dn__time.html#gafd6cfd00794054f30d287982a0790113", null ],
    [ "dn_utcToAsn", "group__dn__time.html#ga2989a3706928ee72d6e9a1077a130ae8", null ],
    [ "dn_getAsn", "group__dn__time.html#gadb5824c33f3abc22f764058e1e510f27", null ]
];