var searchData=
[
  ['ch_5fdesc',['CH_DESC',['../group__dn__channel.html#gacab5346246ac4efb7b171cfd40ed1be0',1,'dn_channel.h']]]
];
