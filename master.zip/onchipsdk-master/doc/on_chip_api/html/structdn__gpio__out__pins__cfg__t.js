var structdn__gpio__out__pins__cfg__t =
[
    [ "gpioBitMapToSetGr1", "structdn__gpio__out__pins__cfg__t.html#ad3ed3f52c6988f291004e631bf85f68e", null ],
    [ "gpioBitMapToSetGr2", "structdn__gpio__out__pins__cfg__t.html#a8099d7b6675228b758372c84272f7c4a", null ],
    [ "gpioBitMaptoClrGr1", "structdn__gpio__out__pins__cfg__t.html#acab529e3e17e720060f7ac6c8a26b11a", null ],
    [ "gpioBitMapToClrGr2", "structdn__gpio__out__pins__cfg__t.html#a52fed1ab520f39e272d16c2d2a47935d", null ]
];