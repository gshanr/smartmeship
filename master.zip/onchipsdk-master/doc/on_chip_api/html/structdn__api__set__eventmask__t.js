var structdn__api__set__eventmask__t =
[
    [ "paramId", "structdn__api__set__eventmask__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "eventMask", "structdn__api__set__eventmask__t.html#a36efa0a89b1af84d637e67d7318cdf3f", null ]
];