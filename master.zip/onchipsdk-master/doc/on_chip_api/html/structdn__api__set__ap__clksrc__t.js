var structdn__api__set__ap__clksrc__t =
[
    [ "paramId", "structdn__api__set__ap__clksrc__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "apClkSrc", "structdn__api__set__ap__clksrc__t.html#ab62ce09c44329afe38d10d28a7a2c39c", null ]
];