var structdn__api__loc__rsp__get__service__t =
[
    [ "rc", "structdn__api__loc__rsp__get__service__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "dest", "structdn__api__loc__rsp__get__service__t.html#ad7bc1692a674870b4f4004996459d6bb", null ],
    [ "type", "structdn__api__loc__rsp__get__service__t.html#a7aead736a07eaf25623ad7bfa1f0ee2d", null ],
    [ "status", "structdn__api__loc__rsp__get__service__t.html#a015eb90e0de9f16e87bd149d4b9ce959", null ],
    [ "value", "structdn__api__loc__rsp__get__service__t.html#a84b41d9d81f3abeb38118988f6211f0f", null ]
];