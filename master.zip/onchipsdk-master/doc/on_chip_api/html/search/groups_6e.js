var searchData=
[
  ['notification_20formats',['Notification formats',['../group__loc__intf__notif__formats.html',1,'']]]
];
