var searchData=
[
  ['passthrough_5foff',['PASSTHROUGH_OFF',['../group__module__dnm__local.html#ggad1f5f7a7a35816607939f6930e0429c8a0f62d2423fb33cc4e7c7b8a971ea3767',1,'dnm_local.h']]],
  ['passthrough_5fon',['PASSTHROUGH_ON',['../group__module__dnm__local.html#ggad1f5f7a7a35816607939f6930e0429c8ad618c91b8261f1bbd9c248a38fe17555',1,'dnm_local.h']]]
];
