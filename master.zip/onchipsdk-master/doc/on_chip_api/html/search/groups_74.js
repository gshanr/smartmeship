var searchData=
[
  ['temperature',['Temperature',['../group__device__temperature.html',1,'']]],
  ['time',['time',['../group__dn__time.html',1,'']]]
];
