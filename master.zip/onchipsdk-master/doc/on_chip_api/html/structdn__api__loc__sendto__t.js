var structdn__api__loc__sendto__t =
[
    [ "socketId", "structdn__api__loc__sendto__t.html#a13a24911b35c9f0cf779764a55faabc9", null ],
    [ "destAddr", "structdn__api__loc__sendto__t.html#a96cf88feddf7d85534cb24e4b9e99d82", null ],
    [ "destPort", "structdn__api__loc__sendto__t.html#a27c9d08b5d90a05dfe52f829ee738089", null ],
    [ "serviceType", "structdn__api__loc__sendto__t.html#a66e71f84b7bf4d9c14fb941830517c99", null ],
    [ "priority", "structdn__api__loc__sendto__t.html#a6a5183df4c54c3e28dc8dc704f2487d5", null ],
    [ "packetId", "structdn__api__loc__sendto__t.html#a3609b8fabc95f20578b60c3205d4e215", null ],
    [ "payload", "structdn__api__loc__sendto__t.html#ad5215ed66763dfdd9a6ef010aa2def37", null ]
];