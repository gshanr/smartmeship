var structdn__api__loc__rsp__open__socket__t =
[
    [ "rc", "structdn__api__loc__rsp__open__socket__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "socketId", "structdn__api__loc__rsp__open__socket__t.html#a13a24911b35c9f0cf779764a55faabc9", null ]
];