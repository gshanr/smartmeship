var structdn__adc__drv__ioctl__rdac__t =
[
    [ "rdacOffset", "structdn__adc__drv__ioctl__rdac__t.html#a77b9f4375f50c3a119cad260ea0e43fe", null ]
];