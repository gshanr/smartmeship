var searchData=
[
  ['device_20api',['Device API',['../group__device__api.html',1,'']]],
  ['devices',['Devices',['../group___devices.html',1,'']]]
];
