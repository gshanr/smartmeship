var searchData=
[
  ['random',['random',['../group__device__rand.html',1,'']]],
  ['raw_20local_20interface',['Raw Local Interface',['../group__loc__intf.html',1,'']]],
  ['request_2fresponse_20formats',['Request/response formats',['../group__loc__intf__reqresp__formats.html',1,'']]]
];
