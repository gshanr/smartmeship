var structdn__exec__par__hdr__t =
[
    [ "signature", "structdn__exec__par__hdr__t.html#aebdeab3038ba473ab18875c1bc10f5d7", null ],
    [ "upgrade", "structdn__exec__par__hdr__t.html#a61e184d7668d4279dd042d281af87cdf", null ],
    [ "crc", "structdn__exec__par__hdr__t.html#a7417f1cf86507427f2919d53b74df048", null ],
    [ "len", "structdn__exec__par__hdr__t.html#af920c89db6b0d15d874a78bf5fce9a4b", null ],
    [ "version", "structdn__exec__par__hdr__t.html#ab91f5a76a5e06ee7ea72f5df7c9068c1", null ],
    [ "appId", "structdn__exec__par__hdr__t.html#a50e438b64fea06036e55a8d3c4fb4583", null ],
    [ "vendorId", "structdn__exec__par__hdr__t.html#a8865044b0e3ecffef887ad9fa19d56c9", null ],
    [ "reserved", "structdn__exec__par__hdr__t.html#aa0867a15e336d35471b46cca3385b5d1", null ]
];