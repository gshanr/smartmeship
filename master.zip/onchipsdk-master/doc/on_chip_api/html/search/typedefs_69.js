var searchData=
[
  ['isoktoprocessnotifscb_5ft',['isOkToProcessNotifsCb_t',['../group__module__dnm__local.html#gad6b0cfb7e56f1e9ae52ae95dea1baa2c',1,'dnm_local.h']]]
];
