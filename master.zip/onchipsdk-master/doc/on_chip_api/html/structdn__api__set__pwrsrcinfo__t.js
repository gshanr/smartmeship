var structdn__api__set__pwrsrcinfo__t =
[
    [ "paramId", "structdn__api__set__pwrsrcinfo__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "info", "structdn__api__set__pwrsrcinfo__t.html#ac8c7f259d6fd331e726ecfdb5b042a07", null ]
];