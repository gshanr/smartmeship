var structdn__gpio__ioctl__cfg__out__t =
[
    [ "initialLevel", "structdn__gpio__ioctl__cfg__out__t.html#a60c818c002ee4d436cc32928d25886a0", null ]
];