var structdn__fs__fileinfo__t =
[
    [ "mode", "structdn__fs__fileinfo__t.html#a1a6b6fb557d8d37d59700faf4e4c9167", null ],
    [ "status", "structdn__fs__fileinfo__t.html#a85488c9ff4e6d37baf45a5e743d7fa2b", null ],
    [ "owner", "structdn__fs__fileinfo__t.html#a29914836b0c0a23b84f25fba8043e15c", null ],
    [ "len", "structdn__fs__fileinfo__t.html#a966e35e1f011dee892023d867fe3a3b2", null ],
    [ "name", "structdn__fs__fileinfo__t.html#aae68a74bbbb6ebd9476a00cdfeddb4e3", null ]
];