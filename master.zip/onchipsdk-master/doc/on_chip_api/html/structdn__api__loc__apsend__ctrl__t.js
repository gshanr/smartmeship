var structdn__api__loc__apsend__ctrl__t =
[
    [ "reserved", "structdn__api__loc__apsend__ctrl__t.html#a8b66539519c55b3392afc2de6af9d836", null ],
    [ "linkCtrl", "structdn__api__loc__apsend__ctrl__t.html#ac2f9cd361f7f762d86b4e953f856f656", null ],
    [ "priority", "structdn__api__loc__apsend__ctrl__t.html#a6c96ac33e84a1675226aa3875c17e39e", null ],
    [ "packetId", "structdn__api__loc__apsend__ctrl__t.html#a3609b8fabc95f20578b60c3205d4e215", null ],
    [ "frameId", "structdn__api__loc__apsend__ctrl__t.html#a98e8e9da9e673d06ac9dba242c9df1ba", null ],
    [ "timeslot", "structdn__api__loc__apsend__ctrl__t.html#aa767e57bb5ac937e06cf187522fbb54c", null ],
    [ "channel", "structdn__api__loc__apsend__ctrl__t.html#a090ea6c18a97b1a5c254ba9e0da06b18", null ],
    [ "dest", "structdn__api__loc__apsend__ctrl__t.html#a4bb0060d6354ce0fe5bde07176e63ced", null ]
];