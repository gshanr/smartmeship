var structdn__cli__register_cmd__t =
[
    [ "hdr", "structdn__cli__register_cmd__t.html#a33cf9f5c6cd1f55e3c9ab55c25c478be", null ],
    [ "data", "structdn__cli__register_cmd__t.html#a5fa551ffe0e8bba941fecf9d9fe4a369", null ]
];