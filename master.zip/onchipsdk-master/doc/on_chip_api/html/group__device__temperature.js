var group__device__temperature =
[
    [ "DN_TEMP_GET_QUARTER_DEG_C", "group__device__temperature.html#ga5730c327e7256499832a70c686542734", null ],
    [ "DN_TEMP_GET_TENTH_DEG_C", "group__device__temperature.html#ga2db5cc2e0fd751f5f9e7c6f1fbacfca6", null ],
    [ "DN_TEMP_GET_DEG_C", "group__device__temperature.html#ga9ebfe15f0ca67093e3fc4b5b2b0cb2bb", null ],
    [ "DN_TEMP_GET_FRAC_DEG_C", "group__device__temperature.html#ga1eb3f479f5197fd277dfb27ca932e6f4", null ]
];