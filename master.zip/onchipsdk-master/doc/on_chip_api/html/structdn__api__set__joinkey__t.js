var structdn__api__set__joinkey__t =
[
    [ "paramId", "structdn__api__set__joinkey__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "joinKey", "structdn__api__set__joinkey__t.html#aba36e2ff66c8898e3910920971ef6c18", null ]
];