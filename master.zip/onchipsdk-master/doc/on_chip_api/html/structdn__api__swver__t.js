var structdn__api__swver__t =
[
    [ "major", "structdn__api__swver__t.html#ae4bdf88747bde578d2a36bb8422d1042", null ],
    [ "minor", "structdn__api__swver__t.html#a9c7be536dcf357d2e3c555ee565f1e0b", null ],
    [ "patch", "structdn__api__swver__t.html#ae4ba0a79a7e162859d0b9b062f2cf3cb", null ],
    [ "build", "structdn__api__swver__t.html#a8cf2581ac9e7317415c5eea403ed995f", null ]
];