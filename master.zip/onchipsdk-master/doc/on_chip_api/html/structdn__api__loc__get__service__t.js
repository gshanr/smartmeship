var structdn__api__loc__get__service__t =
[
    [ "dest", "structdn__api__loc__get__service__t.html#ad7bc1692a674870b4f4004996459d6bb", null ],
    [ "type", "structdn__api__loc__get__service__t.html#a7aead736a07eaf25623ad7bfa1f0ee2d", null ]
];