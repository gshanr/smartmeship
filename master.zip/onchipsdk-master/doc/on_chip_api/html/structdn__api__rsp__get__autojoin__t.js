var structdn__api__rsp__get__autojoin__t =
[
    [ "rc", "structdn__api__rsp__get__autojoin__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__autojoin__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "mode", "structdn__api__rsp__get__autojoin__t.html#a6f850a24512f7d3dbabb1345cf61cc6f", null ]
];