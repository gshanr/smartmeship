var structdn__i2c__ioctl__frequency__t =
[
    [ "frequency", "structdn__i2c__ioctl__frequency__t.html#abc7c2b8fc0432e1f1f6f07123a99a4a2", null ]
];