var structdn__api__set__netid__t =
[
    [ "paramId", "structdn__api__set__netid__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "netId", "structdn__api__set__netid__t.html#a2cb6a8718a4cd970665d912c728fa408", null ]
];