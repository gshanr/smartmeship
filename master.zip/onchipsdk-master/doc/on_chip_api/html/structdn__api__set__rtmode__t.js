var structdn__api__set__rtmode__t =
[
    [ "paramId", "structdn__api__set__rtmode__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "mode", "structdn__api__set__rtmode__t.html#a1a6b6fb557d8d37d59700faf4e4c9167", null ]
];