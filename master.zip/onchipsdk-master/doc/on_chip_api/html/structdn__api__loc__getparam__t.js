var structdn__api__loc__getparam__t =
[
    [ "paramId", "structdn__api__loc__getparam__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "payload", "structdn__api__loc__getparam__t.html#ad5215ed66763dfdd9a6ef010aa2def37", null ]
];