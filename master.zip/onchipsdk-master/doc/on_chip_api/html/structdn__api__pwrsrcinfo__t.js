var structdn__api__pwrsrcinfo__t =
[
    [ "maxStCurrent", "structdn__api__pwrsrcinfo__t.html#a9303d863ddd2f1057fdfa86b5d05e989", null ],
    [ "minLifeTime", "structdn__api__pwrsrcinfo__t.html#a2afff91b350b6e86faea2b82804bd9ab", null ],
    [ "limit", "structdn__api__pwrsrcinfo__t.html#adb7d035f38e55155cf1ce0b17fb5cf1a", null ]
];