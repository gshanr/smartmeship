var structdn__cli__register_cmd_hdr__t =
[
    [ "chDesc", "structdn__cli__register_cmd_hdr__t.html#ad937814de2a616dc9e7fd923784dabea", null ],
    [ "lenCmd", "structdn__cli__register_cmd_hdr__t.html#aee5692682b9753214fff2b5e31418c47", null ],
    [ "cmdId", "structdn__cli__register_cmd_hdr__t.html#acce54cce1fefd5461438cf29edb494d8", null ],
    [ "accessLevel", "structdn__cli__register_cmd_hdr__t.html#a04599b857463522758825102fdd33ce7", null ]
];