var structdn__api__rsp__get__advkey__t =
[
    [ "rc", "structdn__api__rsp__get__advkey__t.html#aa4fd90a56ce14cd9cc93f81091801273", null ],
    [ "paramId", "structdn__api__rsp__get__advkey__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "key", "structdn__api__rsp__get__advkey__t.html#aec4110a8642ae46fa4a758fd894e1a4c", null ]
];