var structdn__api__pwrlim__t =
[
    [ "currentLimit", "structdn__api__pwrlim__t.html#a9999b9e9ce2a88de1b25c57cdb440559", null ],
    [ "dischargePeriod", "structdn__api__pwrlim__t.html#a1cb9df4d589e7313fd7a2803f50d0bee", null ],
    [ "rechargePeriod", "structdn__api__pwrlim__t.html#a5fbce3166b319c2c3c599768bf559ef8", null ]
];