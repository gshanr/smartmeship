var structdn__api__loc__socket__info__t =
[
    [ "index", "structdn__api__loc__socket__info__t.html#a3bda97eaa781a79b23cdfe9a63841b51", null ]
];