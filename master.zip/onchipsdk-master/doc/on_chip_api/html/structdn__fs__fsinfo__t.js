var structdn__fs__fsinfo__t =
[
    [ "shortPageSize", "structdn__fs__fsinfo__t.html#a5531f98a2df0bbe4d63b19b168044ffc", null ],
    [ "longPageSize", "structdn__fs__fsinfo__t.html#aff8011635801b10933af84909aeef2e6", null ],
    [ "numOfPagesUsed", "structdn__fs__fsinfo__t.html#a08ebd524440365e71a2533dc47c6edef", null ],
    [ "maxNumOfPages", "structdn__fs__fsinfo__t.html#ad157b8e10345bdeef5993ae53375a3c2", null ],
    [ "numOfFilesUsed", "structdn__fs__fsinfo__t.html#a200be165d88a9930b8802d43d89ff64d", null ],
    [ "maxNumOfFiles", "structdn__fs__fsinfo__t.html#af42df6d4bdc7a9322130e6ce22c62276", null ]
];