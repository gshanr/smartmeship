var structdn__gpio__notif__t =
[
    [ "gpioDeviceId", "structdn__gpio__notif__t.html#a2de25fec711d65d6905028c1a2127a52", null ],
    [ "level", "structdn__gpio__notif__t.html#a4b5ec8dc4297b5fa6c3c174f7a473122", null ]
];