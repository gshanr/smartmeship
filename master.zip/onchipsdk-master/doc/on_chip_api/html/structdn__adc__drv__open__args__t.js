var structdn__adc__drv__open__args__t =
[
    [ "loadBattery", "structdn__adc__drv__open__args__t.html#abc252fef0aa7e74440b414139997e9c2", null ],
    [ "rdacOffset", "structdn__adc__drv__open__args__t.html#a77b9f4375f50c3a119cad260ea0e43fe", null ],
    [ "vgaGain", "structdn__adc__drv__open__args__t.html#a7c3a35611c921762630949021589276f", null ],
    [ "fBypassVga", "structdn__adc__drv__open__args__t.html#a4c126e5cc058790d3e001840a62159e0", null ]
];