var structdn__api__set__dutycycle__t =
[
    [ "paramId", "structdn__api__set__dutycycle__t.html#aabb4c6c2ea2dc965dbb305a92eca6a7e", null ],
    [ "dutyCycle", "structdn__api__set__dutycycle__t.html#a58fb21fa11ffbc9af0586c5f155e0ffa", null ]
];